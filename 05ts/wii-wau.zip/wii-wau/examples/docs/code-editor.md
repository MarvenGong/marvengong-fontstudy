## CodeEditor 编码
常用的编码。

### 基础用法

基础的编码用法。

:::demo 测试测试测试。

```html
<wau-code-editor />
```
:::

### Attributes
| 参数 | 说明 | 类型   | 可选值                | 默认值 |
| ---- | ---- | ------ | --------------------- | ------ |
| value | 内容 | object, string | — | —      |
| lang | 格式 | string | — | json      |
| theme | 主题 | string | — | chrome      |
| width | 宽度 | string | — | 100%      |
| height | 高度 | string | — | 200px      |
| fontSize | 字体大小 | number | — | 14      |
| readOnly | 只读 | boolean | — | false      |
| auto | 自适应 | array | boolean | true      |
| options | 其他配置 | object | — | —      |
