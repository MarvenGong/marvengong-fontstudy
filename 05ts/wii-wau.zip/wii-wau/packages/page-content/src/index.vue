<template>
  <div class="w-page-content">
    <slot></slot>
  </div>
</template>

<script>
  export default {
    name: 'WauPageContent'
  };
</script>

