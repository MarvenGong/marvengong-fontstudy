# SINGLE-SPA - 公共组件

此目录存放公共业务组件。
