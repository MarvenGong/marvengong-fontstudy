import { IframePost } from './post'

export { IframePost }
