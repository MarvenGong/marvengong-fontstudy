import React from "react";
import { Layout, ExternalLink, Card } from "@tencent/tea-component";
const { Body, Content } = Layout;

export function Home() {
  return (
    <Body>
      <Content>
        <Content.Header
          title="Home"
          operation={<ExternalLink weak>Home</ExternalLink>}
        ></Content.Header>
        <Content.Body>
          <Card>
            <Card.Body>Home</Card.Body>
          </Card>
        </Content.Body>
      </Content>
    </Body>
  );
}
