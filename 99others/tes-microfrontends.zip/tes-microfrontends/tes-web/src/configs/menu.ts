import { AppMenu } from "@tea/app/types";
import { app } from '@tea/app';

/**
 * 定义导航菜单
 */
export const menu: AppMenu = {
  title: "SINGLE-SPA",
  items: [
    { route: "/", title: "Home" },
    { route: "/app1", title: "第一个应用" },
    { route: "/tes-web", title: "综能工场" }
  ]
};
