## Upload 上传
通过点击或者拖拽上传文件

### 点击上传


:::demo 测试测试测试。

```html
<wau-upload />
```
:::

### Attributes
| 参数 | 说明 | 类型   | 可选值                | 默认值 |
| ---- | ---- | ------ | --------------------- | ------ |
| size | 尺寸 | string | medium / small / mini | —      |
