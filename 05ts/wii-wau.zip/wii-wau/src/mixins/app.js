/**
 * 通用混合
 * */

export default {
  methods: {}
}
