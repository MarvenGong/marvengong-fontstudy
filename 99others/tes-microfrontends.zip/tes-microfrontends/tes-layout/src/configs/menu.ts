import { AppMenu } from "@tea/app/types";
import { app } from '@tea/app';

/**
 * 定义导航菜单
 */
export const menu: AppMenu = {
  title: "SINGLE-SPA",
  items: [
    { route: "/", title: "Home" },
    { route: "/vuedemo", title: "第一个Vue应用" },
    { route: "/tes-web", title: "综能工场" },
    { route: "/tes-carbon", title: "碳盘查" }
  ]
};
