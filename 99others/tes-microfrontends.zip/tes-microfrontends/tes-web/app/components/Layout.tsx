import React, { Suspense } from "react";
import { withRouter, RouteComponentProps, Router, Switch, Route } from "react-router-dom";
import { Layout as TeaLayout, NavMenu } from "@tencent/tea-component";
import Menu from "./Menu";
import { AppMenu } from "../types";
import {Home} from '@src/routes/home';
import {Users} from '@src/routes/users';
const { Header, Body, Sider } = TeaLayout;

interface LayoutProps extends RouteComponentProps<any> {
  menu: AppMenu;
}

export default withRouter<LayoutProps, React.ComponentType<LayoutProps>>(
  function Layout({ history, menu, children }) {
    return (
      <Router history={history}>
        <Switch>
          <Route exact path="/tes-web" component={Home} />
          <Route exact path="/tes-web/home" component={Home} />
          <Route exact path="/tes-web/users" component={Users} />
        </Switch>
      </Router>
    );
  }
);
