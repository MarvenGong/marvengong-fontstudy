import React from "react";
import { Layout, ExternalLink, Card } from "@tencent/tea-component";
import { Link } from "react-router-dom";
const { Body, Content } = Layout;

export function Home() {
  return (
    <Body>
      <Content>
        <Content.Header
          title="Home"
          operation={<ExternalLink weak>Home</ExternalLink>}
        ></Content.Header>
        <Content.Body>
          <Card>
            <Card.Body>
            Home
            <p><Link to="/tes-web/users">users</Link></p>
            </Card.Body>
          </Card>
        </Content.Body>
      </Content>
    </Body>
  );
}
