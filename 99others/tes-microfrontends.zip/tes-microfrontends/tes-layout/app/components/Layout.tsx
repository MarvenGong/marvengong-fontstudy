import React from "react";
import { withRouter, RouteComponentProps } from "react-router-dom";
import { Layout as TeaLayout, NavMenu } from "@tencent/tea-component";
import Menu from "./Menu";
import { AppMenu } from "../types";

const { Header, Body, Sider } = TeaLayout;

interface LayoutProps extends RouteComponentProps<any> {
  menu: AppMenu;
}

export default withRouter<LayoutProps, React.ComponentType<LayoutProps>>(
  function Layout({ history, menu, children }) {
    return (
      <TeaLayout style={{height: '100vh'}}>
        <Header>
          <NavMenu
            left={
              <NavMenu.Item type="logo" onClick={() => history.push("/")}>
                <img
                  src="//imgcache.qq.com/qcloud/app/tea/logo.svg"
                  alt="logo"
                />
              </NavMenu.Item>
            }
          />
        </Header>
        <Body>
          {menu && (
            <Sider style={{width: 222}}>
              <Menu menu={menu} />
            </Sider>
          )}
          <div className="layout-right-main" style={{width: '100%', height: '100%'}}>
            {/* {children} */}
            <div id="single-spa-application:vuedemo"></div>
            <div id="single-spa-application:tesWeb"></div>
            <div id="single-spa-application:tesCarbon"></div>
          </div>

        </Body>
      </TeaLayout>
    );
  }
);
