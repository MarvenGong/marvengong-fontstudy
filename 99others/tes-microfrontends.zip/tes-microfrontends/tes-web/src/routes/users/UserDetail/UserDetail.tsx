import React, { useState, useEffect, FC } from 'react';
import { Layout, Card } from "@tencent/tea-component";
import { Router, Route, Switch, Link, useParams } from "react-router-dom";
import { useHistory } from '@tea/app';
const { Body, Content } = Layout;
import './style.less';
interface IUserDetailProps {
  name?: string;
}
const UserDetail: FC<IUserDetailProps> = (props: IUserDetailProps) => {
  const history = useHistory();

  return (
    <Content>
      <Content.Header
        title="Users"
        // showBackButton
        // onBackButtonClick={() => history.push("/users")}
      />
      <Content.Body>
        <Card>
          <Card.Body>名字</Card.Body>
        </Card>
      </Content.Body>
    </Content>
  );
};
export default UserDetail;
