import React from "react";
import { Layout, Card } from "@tencent/tea-component";
import { Router, Route, Switch, Link, useParams } from "react-router-dom";
import { useHistory } from '@tea/app';
import UserDetail from "./UserDetail";
const { Body, Content } = Layout;

function UserOverview() {
  return (
    <Content>
      <Content.Header title="Users" />
      <Content.Body>
        <Card>
          <Card.Body>
            <Link to="/tes-web/home">返回首页</Link>
            <br />
            <Link to="/tes-web/detail">Alice</Link>
            <br />
            <Link to="/tes-web/detail">Bob</Link>
          </Card.Body>
        </Card>
      </Content.Body>
    </Content>
  );
}

export function Users() {
  const history = useHistory();
  return (
    <Body className="user-manage">
      <Router history={history}>
        <Switch>
          <Route exact path="/tes-web/users" component={UserOverview} />
          <Route exact path="/tes-web/detail" component={UserDetail} />
        </Switch>
      </Router>
    </Body>
  );
}
