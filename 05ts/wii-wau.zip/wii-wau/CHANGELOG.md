# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 1.0.0 (2020-11-26)


### Features

* init ([13cac8b](https://e.coding.net///commit/13cac8b0d1826e9862804e8cd8ad6372c1bd8bc5))


### Bug Fixes

* bump version ([9ed3942](https://e.coding.net///commit/9ed39426572e20f99ea94d97c3a807d2d2ea02d0))
