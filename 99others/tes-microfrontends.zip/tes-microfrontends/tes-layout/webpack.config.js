const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-react-ts");
const lessRegex = /\.less$/;
const lessModuleRegex = /\.module\.less$/;
const path = require('path');
const isEnvProduction = false;
// 参数lessOptions为添加项
module.exports = (webpackConfigEnv, argv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: "tes",
    projectName: "web",
    webpackConfigEnv,
    argv,
  });

  return merge(defaultConfig, {
    // modify the webpack config however you'd like to by adding to this object
    // output: {
    //   // filename: '[name].js',
    //   // publicPath: 'tes-web' + '/',
    //   // path: path.resolve(__dirname, '../../release/' + APP_NAME),
    //   libraryTarget: 'umd',
    //   // library: 'test-web'
    // },
    // 配置less模块
    devServer: {
      static: {
        directory: path.join(__dirname, 'public'),
      },
      port: 8083,
    },
    resolve: {
      alias: {
        '@tea/app': '/app'
      }
    },
    module: {
      rules: [
        {
          test: /\.less$/i,
          use: [
            {
              loader: 'style-loader',
            },
            {
              loader: 'css-loader',
            },
            {
              loader: 'less-loader',
              options: {
                lessOptions: {
                  strictMath: true,
                },
              },
            },
          ],
        },
      ],
    },
  });
};
