export const wauPrefix = 'wau';
