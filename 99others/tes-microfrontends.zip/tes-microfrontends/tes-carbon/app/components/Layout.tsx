import React from "react";
import { withRouter, RouteComponentProps } from "react-router-dom";
import { Layout as TeaLayout, NavMenu } from "@tencent/tea-component";
import Menu from "./Menu";
import { AppMenu } from "../types";

const { Header, Body, Sider } = TeaLayout;

interface LayoutProps extends RouteComponentProps<any> {
  menu: AppMenu;
}

export default withRouter<LayoutProps, React.ComponentType<LayoutProps>>(
  function Layout({ history, menu, children }) {
    return (
      <div style={{fontSize: 48}}>碳盘查</div>
    );
  }
);
