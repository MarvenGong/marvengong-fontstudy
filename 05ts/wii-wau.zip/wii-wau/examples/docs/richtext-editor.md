## RichtextEditor 布局
常用的富文本。

### 基础用法

基础的富文本用法。

:::demo 测试测试测试。

```html
<wau-richtext-editor />
```
:::

