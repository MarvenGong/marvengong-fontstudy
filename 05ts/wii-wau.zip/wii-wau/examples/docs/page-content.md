## Content 布局
常用的操作按钮。

### 基础用法

基础的按钮用法。

:::demo 测试测试测试。

```html
<wau-page-content />
```
:::

### Attributes
| 参数 | 说明 | 类型   | 可选值                | 默认值 |
| ---- | ---- | ------ | --------------------- | ------ |
| size | 尺寸 | string | medium / small / mini | —      |
