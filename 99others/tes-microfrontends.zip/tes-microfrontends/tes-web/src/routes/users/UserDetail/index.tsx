import UserDetail from './UserDetail';
export default UserDetail;
