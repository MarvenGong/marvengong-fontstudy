import { setPublicPath } from 'systemjs-webpack-interop'

setPublicPath('vuedemo', 2)