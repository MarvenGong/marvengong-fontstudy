<template>
  <span id="app1">
    Vue 项目被挂载!
    <p>修改代码可以自动更新</p>
    <router-view></router-view>
  </span>
</template>

<style>
#app1 {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
